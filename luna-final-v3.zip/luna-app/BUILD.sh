#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Luna - Cycle Tracker  |  Build & Sign APK for Google Play
#  Run this script from the luna-app/ directory
# ═══════════════════════════════════════════════════════════════
set -e
cd "$(dirname "$0")"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}   ✓ $1${NC}"; }
err()  { echo -e "${RED}   ✗ ERROR: $1${NC}"; exit 1; }
warn() { echo -e "${YELLOW}   ⚠ $1${NC}"; }

echo ""
echo "🌸  Luna APK Builder  🌸"
echo "══════════════════════════"

# ─── Step 1: Validate requirements ───────────────────────────
echo -e "\n1️⃣  Checking requirements..."

command -v java >/dev/null 2>&1    || err "Java not found. Install JDK 17+: https://adoptium.net"
command -v node >/dev/null 2>&1    || err "Node.js not found. Install Node 18+: https://nodejs.org"
command -v keytool >/dev/null 2>&1 || err "keytool not found. Make sure JDK (not just JRE) is installed"

JAVA_VER=$(java -version 2>&1 | head -1)
ok "Java: $JAVA_VER"
ok "Node: $(node --version)"

[ -n "$ANDROID_HOME" ] || err "ANDROID_HOME is not set.\n   Mac:     export ANDROID_HOME=\$HOME/Library/Android/sdk\n   Windows: set ANDROID_HOME=%LOCALAPPDATA%\\Android\\Sdk\n   Linux:   export ANDROID_HOME=\$HOME/Android/Sdk"
[ -d "$ANDROID_HOME/platform-tools" ] || err "Android SDK platform-tools not found in \$ANDROID_HOME"
ok "Android SDK: $ANDROID_HOME"

# ─── Step 2: Install Node dependencies ───────────────────────
echo -e "\n2️⃣  Installing dependencies..."
if [ ! -d "node_modules" ]; then
    npm install || err "npm install failed"
fi
ok "Dependencies ready"

# ─── Step 3: Sync web assets into Android ────────────────────
echo -e "\n3️⃣  Syncing web assets to Android..."
npx cap sync android 2>&1 | grep -E "(copy|update|sync|error|Error)" || true
ok "Assets synced"

# ─── Step 4: Keystore setup ──────────────────────────────────
echo -e "\n4️⃣  Keystore setup..."
KEYSTORE="luna-release.keystore"
STORE_PASS="lunaSecure#2026"
KEY_ALIAS="luna"
KEY_PASS="lunaSecure#2026"

if [ ! -f "$KEYSTORE" ]; then
    echo "   Generating new release keystore (save this file securely!)..."
    keytool -genkey -v \
        -keystore "$KEYSTORE" \
        -alias "$KEY_ALIAS" \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -dname "CN=Luna Cycle Tracker, OU=Mobile Apps, O=Luna, L=Unknown, S=Unknown, C=US" \
        -storepass "$STORE_PASS" \
        -keypass "$KEY_PASS" 2>&1 | tail -3
    ok "Keystore generated: $KEYSTORE"
    echo ""
    warn "IMPORTANT: Back up $KEYSTORE immediately!"
    warn "Without it, you cannot publish updates to the same Play Store app."
    echo ""
else
    ok "Keystore already exists: $KEYSTORE"
fi

# ─── Step 5: Build release APK ───────────────────────────────
echo -e "\n5️⃣  Building release APK (this takes 2–5 minutes)..."
cd android

chmod +x gradlew
./gradlew assembleRelease \
    -PLUNA_STORE_FILE="../../$KEYSTORE" \
    -PLUNA_STORE_PASSWORD="$STORE_PASS" \
    -PLUNA_KEY_ALIAS="$KEY_ALIAS" \
    -PLUNA_KEY_PASSWORD="$KEY_PASS" \
    --no-daemon \
    --stacktrace 2>&1 | grep -E "(BUILD|FAILED|error:|Error|warning:|> Task)" | tail -20

cd ..

APK_SRC="android/app/build/outputs/apk/release/app-release.apk"
APK_DEST="Luna-CycleTracker-v1.0.apk"

if [ -f "$APK_SRC" ]; then
    cp "$APK_SRC" "$APK_DEST"
    SIZE=$(du -sh "$APK_DEST" | cut -f1)
    echo ""
    echo "══════════════════════════════════════════════════════"
    echo -e "${GREEN}✅  BUILD SUCCESSFUL!${NC}"
    echo "   APK file: $APK_DEST"
    echo "   Size:     $SIZE"
    echo ""
    echo "📋  Upload to Google Play Store:"
    echo "   1. Go to play.google.com/console"
    echo "   2. Create app → Health & Fitness"
    echo "   3. Production → Create release → Upload APK"
    echo "   4. Use store listing from PLAYSTORE.md"
    echo "══════════════════════════════════════════════════════"
else
    err "APK not found at $APK_SRC — build failed. Run with --stacktrace for details."
fi
