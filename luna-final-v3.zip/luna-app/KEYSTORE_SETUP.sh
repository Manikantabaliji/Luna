#!/bin/bash
# ═══════════════════════════════════════════════════
#  Luna - Keystore generator + GitHub Secrets helper
# ═══════════════════════════════════════════════════
echo ""
echo "🔑 Luna Keystore Setup"
echo "════════════════════"
echo ""
echo "This creates your signing keystore and shows you the"
echo "GitHub Secrets values to paste into your repo."
echo ""

# Generate keystore
if [ ! -f "luna-release.keystore" ]; then
  keytool -genkey -v \
    -keystore luna-release.keystore \
    -alias luna \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=Luna App, OU=Mobile, O=LunaApp, L=City, S=State, C=IN" \
    -storepass lunaSecure2026 \
    -keypass lunaSecure2026
  echo "✓ Keystore created"
else
  echo "✓ Keystore already exists"
fi

echo ""
echo "════════════════════════════════════════════════════════"
echo "📋 Copy these values into GitHub → Settings → Secrets"
echo "   (Your repo → Settings → Secrets and variables → Actions)"
echo "════════════════════════════════════════════════════════"
echo ""
echo "Secret name:  KEYSTORE_BASE64"
echo "Secret value: (run the command below and paste the output)"
echo ""
echo "  base64 -w 0 luna-release.keystore"
echo ""
echo "Secret name:  KEYSTORE_PASSWORD"
echo "Secret value: lunaSecure2026"
echo ""
echo "Secret name:  KEY_ALIAS"
echo "Secret value: luna"
echo ""
echo "Secret name:  KEY_PASSWORD"
echo "Secret value: lunaSecure2026"
echo ""
echo "════════════════════════════════════════════════════════"
echo "⚠️  CRITICAL: Back up luna-release.keystore now!"
echo "   Store in Google Drive + USB + email to yourself."
echo "   Losing it = can never update app on Play Store."
echo "════════════════════════════════════════════════════════"
echo ""
