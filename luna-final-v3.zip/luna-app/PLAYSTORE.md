# Luna - Cycle Tracker | Play Store Listing

## App details
- **Package name:** com.lunaapp.cycletracker
- **App name:** Luna - Cycle Tracker
- **Category:** Health & Fitness
- **Content rating:** Teen
- **Price:** Free

## Short description (80 chars max)
Privacy-first period & cycle tracker. Your data stays on your phone. Always.

## Full description (4000 chars max)
Luna is a beautifully designed period and cycle tracker that puts your privacy first.

Unlike other period tracking apps, Luna stores ALL your data directly on your device — nothing is uploaded to servers, nothing is shared with third parties. Ever.

🌸 TRACK YOUR CYCLE
• Log your period start and end dates
• Track flow intensity (light, medium, heavy)
• Record 10 common symptoms including cramps, bloating, and fatigue
• Log your daily mood with 6 mood options
• Add personal notes for each day

📅 SMART PREDICTIONS
• Accurate next period predictions based on your cycle history
• Ovulation day calculation
• Fertile window tracking
• Visual 14-day forecast strip
• Cycle phase insights (menstrual, follicular, fertile, luteal)

📊 CYCLE INSIGHTS
• Cycle length history charts
• Most common symptom patterns
• Mood trends throughout your cycle
• Average cycle and period length stats
• Days logged and cycles tracked

🔒 YOUR PRIVACY, GUARANTEED
• Zero cloud storage — all data on your device only
• No account required, no sign-in
• No data sharing with advertisers or third parties
• Export your own data as CSV anytime
• Delete everything with one tap

🌙 BEAUTIFUL DESIGN
• Elegant rose and blush color palette
• Intuitive 5-tab navigation
• Color-coded monthly calendar
• Phase-based wellness tips

WHAT MAKES LUNA DIFFERENT
Most period tracking apps earn money by selling your health data. Luna doesn't. Your cycle data is some of the most personal health information you have — it should stay yours.

Download Luna and take back control of your cycle health data.

## Keywords
period tracker, cycle tracker, menstrual calendar, ovulation tracker, fertility tracker, women health, menstruation, period calendar, PMS tracker, monthly cycle

## Screenshots needed (produce these from a device)
1. Home screen showing cycle ring
2. Log Today screen with symptoms
3. Calendar view with color coding
4. Insights charts
5. Settings / privacy screen

## Privacy policy URL
https://lunaapp.example.com/privacy
(Create a simple privacy policy page — template in PRIVACY_POLICY.md)
