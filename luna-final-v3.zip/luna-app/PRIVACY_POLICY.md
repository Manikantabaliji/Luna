# Luna - Cycle Tracker | Privacy Policy

**Last updated:** May 2026

## Summary
Luna stores all data locally on your device. We collect no personal information, track no usage, and share nothing with anyone.

## Data Collection
Luna does NOT collect any personal data. All information you enter (cycle dates, symptoms, moods, notes) is stored exclusively in your device's local storage using Android's localStorage API.

## Data Sharing
We do not share any data with third parties because we do not have access to your data.

## Data Deletion
You can delete all your data at any time via Settings → Delete all data. Uninstalling the app also removes all data permanently.

## Permissions
- **Storage (Android <10):** Only used to export your CSV backup to your own device. No cloud upload.
- **Notifications:** Used only for period reminders you configure. Sent locally from your device.
- **Internet:** Required by the Android WebView component. Luna makes no network requests.

## Contact
For questions: luna@example.com
