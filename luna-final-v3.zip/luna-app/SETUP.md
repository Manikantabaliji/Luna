# Luna APK — Complete Setup & Build Guide

## The Error You Saw (Fixed)
Your GitHub Actions workflow was using `actions/upload-artifact@v3` which was deprecated.
**The new workflow uses `@v4` for all actions.** This is already fixed in `.github/workflows/build.yml`.

---

## Option A: Build via GitHub Actions (Recommended — no Android Studio needed)

### Step 1 — Upload to GitHub
```bash
git init
git add .
git commit -m "Initial Luna app"
git remote add origin https://github.com/YOUR_USERNAME/luna-app.git
git push -u origin main
```

### Step 2 — Set up signing secrets
Run `./KEYSTORE_SETUP.sh` locally, then add these 4 secrets to your GitHub repo:
- Go to: **GitHub repo → Settings → Secrets and variables → Actions → New repository secret**

| Secret Name | Value |
|---|---|
| `KEYSTORE_BASE64` | Output of: `base64 -w 0 luna-release.keystore` |
| `KEYSTORE_PASSWORD` | `lunaSecure2026` |
| `KEY_ALIAS` | `luna` |
| `KEY_PASSWORD` | `lunaSecure2026` |

### Step 3 — Trigger build
Push any commit to `main`. Go to **Actions tab** → watch the build.
Download your APK from the **Artifacts** section when it completes (~5 min).

---

## Option B: Build locally (needs Android Studio)

### Requirements
| Tool | Version | Download |
|---|---|---|
| Java JDK | 17 | https://adoptium.net |
| Android Studio | Latest | https://developer.android.com/studio |
| Node.js | 18+ | https://nodejs.org |

### Setup
```bash
# 1. Set Android SDK path
export ANDROID_HOME=$HOME/Library/Android/sdk          # Mac
# OR
export ANDROID_HOME=$HOME/Android/Sdk                  # Linux
# OR
set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk            # Windows

export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# 2. Install dependencies
npm install

# 3. Generate keystore (first time only)
./KEYSTORE_SETUP.sh

# 4. Build
./BUILD.sh
```

APK location: `android/app/build/outputs/apk/release/app-release.apk`

---

## Upload to Google Play Store

1. Pay one-time **$25** at [play.google.com/console](https://play.google.com/console)
2. Create new app → **Luna - Cycle Tracker**
3. Category: **Health & Fitness**
4. Production → Create release → Upload APK
5. Copy store listing from `PLAYSTORE.md`
6. Host privacy policy (use `PRIVACY_POLICY.md` — free: GitHub Pages or Netlify)
7. Submit for review (3–7 days first submission)

---

## Troubleshooting

**"actions/upload-artifact@v3 deprecated"** → Fixed. Workflow now uses v4. ✓

**"ANDROID_HOME not set"** → Run the export command in Setup above.

**"Gradle build failed"** → Ensure JDK 17 is installed (not 8 or 11).

**"Keystore not found"** → Run `./KEYSTORE_SETUP.sh` first.

**"App crashes on launch"** → Open Chrome on Android, go to `chrome://inspect`, connect phone, see console errors.
