# Capacitor
-keep class com.getcapacitor.** { *; }
-keep class com.lunaapp.cycletracker.** { *; }

# WebView JavaScript Interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# Suppress common warnings
-dontwarn com.google.android.gms.**
-dontwarn org.apache.**
