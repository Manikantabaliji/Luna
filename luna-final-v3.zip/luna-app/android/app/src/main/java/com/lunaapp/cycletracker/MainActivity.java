package com.lunaapp.cycletracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
